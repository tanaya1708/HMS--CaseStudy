package com.happystay.rmsinventorystaff.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection="staff")
public class Staff {
	
	@Id
	private int code;
	private String employee_name;
	private String employee_address;
	private int NIC;
	private double salary;
	private int age;
	private String occupation;
	private String email;

	
	public Staff() {
		
	}


	public Staff(int code, String employee_name, String employee_address, int nIC, double salary, int age,
			String occupation, String email) {
		super();
		this.code = code;
		this.employee_name = employee_name;
		this.employee_address = employee_address;
		NIC = nIC;
		this.salary = salary;
		this.age = age;
		this.occupation = occupation;
		this.email = email;
	}


	public int getCode() {
		return code;
	}


	public void setCode(int code) {
		this.code = code;
	}


	public String getEmployee_name() {
		return employee_name;
	}


	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}


	public String getEmployee_address() {
		return employee_address;
	}


	public void setEmployee_address(String employee_address) {
		this.employee_address = employee_address;
	}


	public int getNIC() {
		return NIC;
	}


	public void setNIC(int nIC) {
		NIC = nIC;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getOccupation() {
		return occupation;
	}


	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
