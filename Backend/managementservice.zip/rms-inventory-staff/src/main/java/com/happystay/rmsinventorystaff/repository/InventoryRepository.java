package com.happystay.rmsinventorystaff.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.happystay.rmsinventorystaff.model.Inventory;



@Repository
public interface InventoryRepository extends MongoRepository<Inventory ,String>{

	@Query("{'inventory_details' : ?0}")
	List<Inventory> findByInventory_Details(String inventory_details);


	@Query("{'inventory_details' : ?0}")
	void deleteByInventory_Details(String inventory_details);


}
