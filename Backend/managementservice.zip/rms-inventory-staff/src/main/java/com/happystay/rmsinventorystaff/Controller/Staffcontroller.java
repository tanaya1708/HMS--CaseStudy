package com.happystay.rmsinventorystaff.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.happystay.rmsinventorystaff.model.Staff;
import com.happystay.rmsinventorystaff.repository.StaffRepository;



@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class Staffcontroller {
	
	@Autowired
	private StaffRepository staffRepository;
	
	 @RequestMapping(value="/staff")
	  public List<Staff> getAllStaff() {
		  return staffRepository.findAll();
	  }
	 @RequestMapping(value="/staff/{code}")
	  public Optional<Staff> getStaff(@PathVariable int code) {
		return staffRepository.findById(code);
	  }
	 
	 @RequestMapping(value="/insertstaff",method=RequestMethod.POST)
	  public void addStaff(@RequestBody Staff staffs) {
		  staffRepository.insert(staffs);
	  }
	 
	 @RequestMapping(value="/staff/{code}",method=RequestMethod.PUT)
	  public void updateStaff(@PathVariable int code, @RequestBody Staff staffs) {
		  staffRepository.save(staffs);
	  }
	 @RequestMapping(value="/staff/{code}",method=RequestMethod.DELETE)
	  public void deleteStaff(@PathVariable int code) {
	    staffRepository.deleteById(code);
	  }
	 
}
