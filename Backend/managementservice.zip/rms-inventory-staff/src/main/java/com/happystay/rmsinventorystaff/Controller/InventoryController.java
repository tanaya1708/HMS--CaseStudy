package com.happystay.rmsinventorystaff.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.happystay.rmsinventorystaff.model.Inventory;
import com.happystay.rmsinventorystaff.repository.InventoryRepository;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class InventoryController {
	
	@Autowired
	private InventoryRepository inventoryRepository;
	
	 @RequestMapping(value="/inventory")
	  public List<Inventory> getAllInventory() {
		  return inventoryRepository.findAll();
	  }

	  @RequestMapping(value="/inventory/{inventory_details}")
	  public List<Inventory> getInventory(@PathVariable(value="inventory_details") String inventory_details) {
		return inventoryRepository.findByInventory_Details(inventory_details);
	  }

	  @RequestMapping(value="/insertinvent",method=RequestMethod.POST)
	  public void addInventory(@RequestBody Inventory inventory) {
		  inventoryRepository.insert(inventory);
	  }

	  @RequestMapping(value="/inventory/{inventory_details}",method=RequestMethod.PUT)
	  public void updateInventory(@PathVariable String inventory_details, @RequestBody Inventory inventory) {
		  inventoryRepository.save(inventory);
	  }

	  @RequestMapping(value="/inventory/{inventory_details}",method=RequestMethod.DELETE)
	  public void deleteInventory(@PathVariable(value="inventory_details")String inventory_details) {
		  inventoryRepository.deleteByInventory_Details(inventory_details);
	  }

}
