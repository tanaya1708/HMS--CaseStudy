package com.happystay.rmsinventorystaff.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection="inventory")
public class Inventory {
	
	@Id
	private String inventory_details;
	private int chair,couches,dining,lamps,beds,mirrors,DVDs,CDs,books,hamper;
	private String guest_details;
	
	public Inventory() {
				
	}
	
	
	public Inventory(int chair, int couches, int dining, int lamps, int beds, int mirrors, int dVDs, int cDs, int books,
			int hamper, String guest_details) {
		super();
		this.chair = chair;
		this.couches = couches;
		this.dining = dining;
		this.lamps = lamps;
		this.beds = beds;
		this.mirrors = mirrors;
		DVDs = dVDs;
		CDs = cDs;
		this.books = books;
		this.hamper = hamper;
		this.guest_details = guest_details;
	}


	public Inventory(String inventory_details) {
		super();
		this.inventory_details = inventory_details;
	}


	public String getInventory_details() {
		return inventory_details;
	}


	public void setInventory_details(String inventory_details) {
		this.inventory_details = inventory_details;
	}


	public int getChair() {
		return chair;
	}


	public void setChair(int chair) {
		this.chair = chair;
	}


	public int getCouches() {
		return couches;
	}


	public void setCouches(int couches) {
		this.couches = couches;
	}


	public int getDining() {
		return dining;
	}


	public void setDining(int dining) {
		this.dining = dining;
	}


	public int getLamps() {
		return lamps;
	}


	public void setLamps(int lamps) {
		this.lamps = lamps;
	}


	public int getBeds() {
		return beds;
	}


	public void setBeds(int beds) {
		this.beds = beds;
	}


	public int getMirrors() {
		return mirrors;
	}


	public void setMirrors(int mirrors) {
		this.mirrors = mirrors;
	}


	public int getDVDs() {
		return DVDs;
	}


	public void setDVDs(int dVDs) {
		DVDs = dVDs;
	}


	public int getCDs() {
		return CDs;
	}


	public void setCDs(int cDs) {
		CDs = cDs;
	}


	public int getBooks() {
		return books;
	}


	public void setBooks(int books) {
		this.books = books;
	}


	public int getHamper() {
		return hamper;
	}


	public void setHamper(int hamper) {
		this.hamper = hamper;
	}


	public String getGuest_details() {
		return guest_details;
	}


	public void setGuest_details(String guest_details) {
		this.guest_details = guest_details;
	}
	
	
	
	
	

}
