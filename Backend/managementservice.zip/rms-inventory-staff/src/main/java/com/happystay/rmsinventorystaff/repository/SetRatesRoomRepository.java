package com.happystay.rmsinventorystaff.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.happystay.rmsinventorystaff.model.SetRatesRoom;

public interface SetRatesRoomRepository extends MongoRepository<SetRatesRoom, Integer>{

}
