package com.happystay.rmsinventorystaff.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
@Document(collection="setRates")
public class SetRatesRoom {
	
	@Id
	private int room_number;
	private Date check_in;
	private Date check_out;
	private int day;
	private int guest;
	private double first_night_price;
	private double extension_price;
	
	
  public SetRatesRoom () {
	}


public SetRatesRoom(int room_number, Date check_in, Date check_out, int day, int guest, double first_night_price,
		double extension_price) {
	super();
	this.room_number = room_number;
	this.check_in = check_in;
	this.check_out = check_out;
	this.day = day;
	this.guest = guest;
	this.first_night_price = first_night_price;
	this.extension_price = extension_price;
}


public int getRoom_number() {
	return room_number;
}


public void setRoom_number(int room_number) {
	this.room_number = room_number;
}


public Date getCheck_in() {
	return check_in;
}


public void setCheck_in(Date check_in) {
	this.check_in = check_in;
}


public Date getCheck_out() {
	return check_out;
}


public void setCheck_out(Date check_out) {
	this.check_out = check_out;
}


public int getDay() {
	return day;
}


public void setDay(int day) {
	this.day = day;
}


public int getGuest() {
	return guest;
}


public void setGuest(int guest) {
	this.guest = guest;
}


public double getFirst_night_price() {
	return first_night_price;
}


public void setFirst_night_price(double first_night_price) {
	this.first_night_price = first_night_price;
}


public double getExtension_price() {
	return extension_price;
}


public void setExtension_price(double extension_price) {
	this.extension_price = extension_price;
}

























}
	