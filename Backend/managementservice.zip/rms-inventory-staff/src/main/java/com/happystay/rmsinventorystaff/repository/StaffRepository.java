package com.happystay.rmsinventorystaff.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.happystay.rmsinventorystaff.model.Staff;

public interface StaffRepository extends MongoRepository<Staff , Integer>{

}
