package com.happystay.rmsinventorystaff.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.happystay.rmsinventorystaff.model.SetRatesRoom;
import com.happystay.rmsinventorystaff.repository.SetRatesRoomRepository;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class SetRatesRoomController {

	@Autowired
	private SetRatesRoomRepository setRatesRoomRepository;
	
	@RequestMapping(value="/rates")
	  public List<SetRatesRoom> getAllRates() {
		  return setRatesRoomRepository.findAll();
	  }
	@RequestMapping(value="/rates/{room_number}")
	  public Optional<SetRatesRoom> getRates(@PathVariable int room_number) {
		return setRatesRoomRepository.findById(room_number);
	  }
	
	@RequestMapping(value="/insertrates",method=RequestMethod.POST)
	  public void addRates(@RequestBody SetRatesRoom setRatesRoom) {
		setRatesRoomRepository.insert(setRatesRoom);
	  }
	
	 @RequestMapping(value="/rates/{room_number}",method=RequestMethod.PUT)
	  public void updateRates(@PathVariable int room_number, @RequestBody SetRatesRoom setRatesRoom) {
		 setRatesRoomRepository.save(setRatesRoom);
	  }
	 @RequestMapping(value="/rates/{room_number}",method=RequestMethod.DELETE)
	  public void deleteRates(@PathVariable int room_number) {
		 setRatesRoomRepository.deleteById(room_number);
	  }


}

