package com.happystay.rmsinventorystaff;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.test.context.junit4.SpringRunner;


import com.happystay.rmsinventorystaff.model.Staff;
import com.happystay.rmsinventorystaff.repository.StaffRepository;


@SpringBootTest

@RunWith(SpringRunner.class)

@TestMethodOrder(OrderAnnotation.class)
class RmsInventoryStaffApplicationTests {
	@Autowired
	private StaffRepository staffRepository;
	
	@Test
	@Order(1)
	public void staffCreate() {
		Staff staff =  new Staff();
		staff.setCode(1);
		staff.setEmployee_name("tanaya");
		staff.setEmployee_address("Mumbai");
		staff.setNIC(12);
		staff.setSalary(35236);
		staff.setOccupation("teacher");
		staff.setAge(21);
		staff.setEmail("tanu@gmail.com");
		assertNotNull(staffRepository.findById(1).get());
		
	}
	  @Test
	  @Order(2) 
	  public void staffReadAll () { 
		  List<Staff> staff = staffRepository.findAll(); 
		  assertThat(staff).size().isGreaterThan(0);
	 }
	  @Test 
	  @Order(3)
	  public void staffRead () { 
		  Staff staffs =
	  staffRepository.findById(1).get(); 
		  assertEquals("tanaya",staffs.getEmployee_name());
		 }
	  
			/*
			 * @Test
			 * 
			 * @Order(4) public void guestUpdate () { Staff staffs
			 * =staffRepository.findById(1).get(); staffs.setAge(20);
			 * staffRepository.save(staffs);
			 * assertNotEquals(21,staffRepository.findById(1).get().getAge()); }
			 */
	/*
	 * @Test
	 * 
	 * @Order(5) public void staffDelete () { staffRepository.deleteById(1);
	 * assertThat(staffRepository.existsById(1)).isFalse(); }
	 */
		 
	 
}
