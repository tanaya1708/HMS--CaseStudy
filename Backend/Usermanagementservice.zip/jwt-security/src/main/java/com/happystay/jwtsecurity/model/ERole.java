package com.happystay.jwtsecurity.model;

public enum ERole {
  ROLE_ADMIN,
  ROLE_MANAGER,
  ROLE_RECEPTIONIST
}
