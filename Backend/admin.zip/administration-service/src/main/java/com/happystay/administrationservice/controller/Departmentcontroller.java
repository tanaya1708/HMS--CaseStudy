package com.happystay.administrationservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.happystay.administrationservice.dao.DepartmentRepo;
import com.happystay.administrationservice.model.Department;



@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class Departmentcontroller {
	
	@Autowired
	private DepartmentRepo departmentRepository;
	
	@RequestMapping(value="/dept")
	@ResponseBody
	  public ResponseEntity<List<Department>> getAllDept() {
		try {
			List<Department> department = departmentRepository.findAll();
			return new ResponseEntity<List<Department>>(department, HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	  }
	 
	 @RequestMapping(value="/dept/{code}")
	 @ResponseBody
	  public Optional<Department> getDept(@PathVariable int code) {
		return departmentRepository.findById(code);
	  }
	 
	 @RequestMapping(value="/insertdept",consumes = MediaType.APPLICATION_JSON_VALUE,method=RequestMethod.POST)
	 public ResponseEntity<Department> addDept(@RequestBody Department dept) {
		  try {
			  departmentRepository.insert(dept);
			  return new ResponseEntity<Department>(dept, HttpStatus.CREATED);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
	 
	 @RequestMapping(value="/dept/{code}",method=RequestMethod.DELETE)
	 public ResponseEntity<Void> deleteDept(@PathVariable int code) {
	    try {
	    	departmentRepository.deleteById(code);
			return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }

	

}
