package com.happystay.reservationservice;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.annotation.Order;
import org.springframework.test.context.junit4.SpringRunner;
import com.happystay.reservationservice.dao.GuestRepository;
import com.happystay.reservationservice.controller.GuestController;
import com.happystay.reservationservice.model.Guest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

@SpringBootTest
@RunWith(SpringRunner.class)

@TestMethodOrder(OrderAnnotation.class)
class ReservationServiceApplicationTests {

	
	@Autowired
	private GuestController guestResource;
	
	@MockBean
	private GuestRepository guestRepository;
	
	
	/*
	 * "assertNotNull()" functionally checks that an object is not null
	 */
	
	@Test
	@Order(1)
	public void guestCreate () {
		Guest guest = new Guest(1L,36473L,"jio","tanaya","Female","pqr@gmail.com","Mumbai");
		when(guestRepository.save(guest));
		assertNotNull(guestRepository.findById(1L).get());
	}
	
	/*
	 * The assertThat is one of the JUnit methods from the Assert object that can be
	 * used to check if a specific value match to an expected one. ... First one if
	 * the actual value and the second is a matcher object. It will then try to
	 * compare this two and returns a boolean result if its a match or not.
	 */
	
	  @Test
	  @Order(2) 
	  public void guestReadAll () { 
		  List<Guest> guests =guestRepository.findAll(); 
		  assertThat(guests).size().isGreaterThan(0);
	 }
	  
	/* Asserts that two objects are equal */
	
	  @Test 
	  @Order(3)
	  public void guestRead () { 
		  Guest guests =
	  guestRepository.findById(1L).get(); 
		  assertEquals("tanaya",guests.getName());
		 }
	  
	/* Asserts that two objects are not equals */
	  
	  @Test
	  
	  @Order(4) public void guestUpdate () 
	  { Guest guests = guestRepository.findById(1L).get(); 
	  guests.setCompany("capgemini");
	  guestRepository.save(guests);
	  assertNotEquals("jio",guestRepository.findById(1L).get().getCompany()); }
	 
	 
	
	/*
	 * @Test
	 * 
	 * @Order(5) public void guestDelete () { guestRepository.deleteById(1L);
	 * assertThat(guestRepository.existsById(1L)).isFalse(); }
	 * 
	 */
}




