package com.happystay.reservationservice.dao;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.happystay.reservationservice.model.Room;

@Repository
public interface RoomRepository extends MongoRepository<Room, LocalDate>{

	//$gte selects the documents where the value of the field is greater than or equal to and $lt select less than

	@Query("{ 'checkIn' : {$gte:?0},'checkOut' : {$lt:?1}}")
    List<Room> findByCheckInAndCheckOut(LocalDate checkIn, LocalDate checkOut);
   
	
	@Query("{'date' : { $gte: ISODate(?0), $lt: ISODate(?1) } }")
    public List<Room> getObjectByDate(LocalDate checkIn, LocalDate checkOut);
    @Query("{'checkIn':{$gte:?0}}")
    List<Room> findByCheckIn(LocalDate checkIn);


	Optional<Room> findById(int id);
  


	

}
