package com.happystay.reservationservice;

import java.text.SimpleDateFormat;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.happystay.reservationservice.dao.BookingRepository;
import com.happystay.reservationservice.dao.GuestRepository;
import com.happystay.reservationservice.dao.RoomRepository;

import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class ReservationServiceApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(ReservationServiceApplication.class, args);
	}
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private RoomRepository roomRepository;
	
    @Autowired
    private  GuestRepository guestRepository;
	    
	    

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Bean
	public Docket swaggerConfiguration() {
		
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.build()
				.apiInfo(apiDetails());
	}

	private ApiInfo apiDetails() {
		return new ApiInfo(
			"Reservation Service",
			"API for searching and fetching booking and guest details",
			"1.0",
			"Free to use",
			new springfox.documentation.service.Contact("Tanaya Jadhav", "https://github.com/tanaya1708", "tanayayjadhav99@gmail.com"),
			"API license",
			"https://github.com/tanaya1708",
			Collections.emptyList());
	}
	


}
