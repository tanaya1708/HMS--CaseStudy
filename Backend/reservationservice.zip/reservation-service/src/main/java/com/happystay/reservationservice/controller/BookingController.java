package com.happystay.reservationservice.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.happystay.reservationservice.dao.BookingRepository;
import com.happystay.reservationservice.dao.GuestRepository;
import com.happystay.reservationservice.dao.RoomRepository;
import com.happystay.reservationservice.model.Booking;
import com.happystay.reservationservice.model.Guest;
import com.happystay.reservationservice.model.Room;

@RestController
//@RequestMapping(value="/bookings")
//@SessionAttributes({"numberRooms"})
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {
	
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private GuestRepository guestRepository;
	
	 @RequestMapping(value="/bookings")
	  public List<Booking> getAllBookings() {
		 return bookingRepository.findAll();
		  	  }
	 
	 @RequestMapping(value="/insertbookings",method=RequestMethod.POST)
	  public void addBooking(@RequestBody Booking bookings) {
			 bookingRepository.insert(bookings);
		 }
	  
	 @RequestMapping(value="/bookings/{code}",method=RequestMethod.DELETE)
	 public ResponseEntity<Void> deleteBooking(@PathVariable int code) {
	    try {
			bookingRepository.deleteById(code);
			return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
	

}
