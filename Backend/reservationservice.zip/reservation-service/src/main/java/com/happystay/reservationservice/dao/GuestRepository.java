package com.happystay.reservationservice.dao;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.happystay.reservationservice.model.Guest;

@Repository
public interface GuestRepository extends MongoRepository<Guest,Long>{

	Optional<Guest> findByName(String name);



}
