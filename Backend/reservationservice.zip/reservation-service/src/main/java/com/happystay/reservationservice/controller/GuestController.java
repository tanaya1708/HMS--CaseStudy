package com.happystay.reservationservice.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.happystay.reservationservice.dao.GuestRepository;
import com.happystay.reservationservice.model.Guest;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class GuestController {
	
	@Autowired
	private GuestRepository guestRepository;
	
	//get all details of guest
	
	@RequestMapping(value="/guest")
	@ResponseBody
	  public ResponseEntity<List<Guest>> getAllGuest() {
		try {
			List<Guest> guest = guestRepository.findAll();
			return new ResponseEntity<List<Guest>>(guest, HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	  }
	 
	 @RequestMapping(value="/guest/{member_code}")
	 @ResponseBody
	  public Optional<Guest> getMember(@PathVariable long member_code) {
		return guestRepository.findById(member_code);
	  }
	 
	 @RequestMapping(value="/insertguest",consumes = MediaType.APPLICATION_JSON_VALUE,method=RequestMethod.POST)
	 public ResponseEntity<Guest> addGuest(@RequestBody Guest guest) {
		  try {
			guestRepository.insert(guest);
			  return new ResponseEntity<Guest>(guest, HttpStatus.CREATED);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }

	 
	 @RequestMapping(value="/guest/{member_code}",method=RequestMethod.PUT)
	  public void updateGuest(@PathVariable long member_code, @RequestBody Guest guest) {
		  guestRepository.save(guest);
	  }
	 
	 
	 @RequestMapping(value="/guest/{member_code}",method=RequestMethod.DELETE)
	 public ResponseEntity<Void> deleteGuest(@PathVariable long member_code) {
	    try {
			guestRepository.deleteById(member_code);
			return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }

}
