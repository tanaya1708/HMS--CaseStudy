package com.happystay.reservationservice.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
@Document(collection="bookings")
public class Booking {
	
	@Id
	private int code;
	private int children;
	@NotBlank
	private int adult;


	@NotBlank
	private String check_IN;


	@NotBlank
	private String check_OUT;
	@NotBlank
	private String status;
	@NotBlank
	private int number_of_nights;
	
	@DBRef(db="rooms")
	private Set<Room> rooms = new HashSet<Room>();
//	
	public Booking() {
		
	}
	
	
	public Booking(int code, int children, int adult, String check_IN, String check_OUT, String status,
			int number_of_nights) {
		super();
		this.code = code;
		this.children = children;
		this.adult = adult;
		this.check_IN = check_IN;
		this.check_OUT = check_OUT;
		this.status = status;
		this.number_of_nights = number_of_nights;
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getChildren() {
		return children;
	}
	public void setChildren(int children) {
		this.children = children;
	}
	public int getAdult() {
		return adult;
	}
	public void setAdult(int adult) {
		this.adult = adult;
	}
	public String getCheck_IN() {
		return check_IN;
	}
	public void setCheck_IN(String check_IN) {
		this.check_IN = check_IN;
	}
	public String getCheck_OUT() {
		return check_OUT;
	}
	public void setCheck_OUT(String check_OUT) {
		this.check_OUT = check_OUT;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getNumber_of_nights() {
		return number_of_nights;
	}
	public void setNumber_of_nights(int number_of_nights) {
		this.number_of_nights = number_of_nights;
	}
	
	
//	@Override
//	public String toString() {
//		return "Booking [code =" + code + ", children =" + children + ", adult =" + adult + ", check_IN =" + check_IN + ",check_OUT= " + check_OUT + ",status= " + status + ", number_of_nights = "+ number_of_nights+ "]";
//	}
//	
	
	
	

}
