package com.happystay.reservationservice.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.happystay.reservationservice.dao.BookingRepository;
import com.happystay.reservationservice.dao.GuestRepository;
import com.happystay.reservationservice.dao.RoomRepository;
import com.happystay.reservationservice.model.Room;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class RoomController {
	   
	@Autowired
	private RoomRepository roomRepository;
	
	    private MongoTemplate mongoTemplate;
	    Logger logger =  LoggerFactory.getLogger(Room.class);
	    @Autowired
	    BookingRepository bookingRepository;
	    
	    @Autowired
	    GuestRepository guestRepository;
	
	    @RequestMapping(value="/rooms")
	    public List<Room> getAll() {
	    	return roomRepository.findAll();
	    }
	    
	    @RequestMapping(value="/insertrooms",method=RequestMethod.POST)
		  public void addRoom(@RequestBody Room room) {
				 roomRepository.insert(room);
		}
	    
	    @RequestMapping(value="/rooms/{id}")
		  public Optional<Room> getRoom(@PathVariable int id) {
			return roomRepository.findById(id);
		  }
		 
	    
		
	    @GetMapping("/rooms/{checkIn}/{checkOut}")

	    public List<Room> getRoom( @PathVariable(value="checkIn")   String checkIn, @PathVariable(value="checkOut") String checkOut )

	    {

	        Query query = new Query();
		
	        LocalDate check =  LocalDate.parse(checkIn,DateTimeFormatter.ISO_DATE);
	        LocalDate checkO = LocalDate.parse(checkOut,DateTimeFormatter.ISO_DATE);

	        Criteria c = new Criteria().where("checkIn").gt(check);
	        query.addCriteria(c);

	        logger.info("room request by dates : " + checkIn +" "+checkOut);

	        logger.info("here"+check);
	        logger.info("hereO"+checkO);
	        logger.debug("check"+check);

	        return this.roomRepository.findByCheckInAndCheckOut(check,checkO);

	    }

	    }
		 
	   
	    
	    

