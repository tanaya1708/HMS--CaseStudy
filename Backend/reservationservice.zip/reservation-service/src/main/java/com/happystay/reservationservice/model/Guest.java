package com.happystay.reservationservice.model;

import java.util.Date;

import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.aggregation.DateOperators.DateToString;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Document(collection="guest")
public class Guest {
	enum Gender {MALE, FEMALE , OTHER}
	
	@Id
	private long member_code;
	@NotBlank
	private long phone_number;
	private String company;
	@NotBlank
	private String name;
	@NotBlank
	private String email;
	@NotBlank
	private String gender;
	@NotBlank
	private String address;
	@NotBlank
	

	private String checkin;

	
	@NotBlank
	private String checkout;
	
	public Guest() {}
	
	

	public Guest(long member_code, long phone_number, String company, String name, String email, String gender,
			String address) {
		super();
		this.member_code = member_code;
		this.phone_number = phone_number;
		this.company = company;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.address = address;
	}



	



	public String getCheckin() {
		return checkin;
	}



	public void setCheckin(String checkin) {
		this.checkin = checkin;
	}



	public String getCheckout() {
		return checkout;
	}



	public void setCheckout(String checkout) {
		this.checkout = checkout;
	}



	public Guest(String checkin, String checkout) {
		super();
		this.checkin = checkin;
		this.checkout = checkout;
	}



	public long getMember_code() {
		return member_code;
	}

	public void setMember_code(long member_code) {
		this.member_code = member_code;
	}

	public long getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(long phone_number) {
		this.phone_number = phone_number;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



	

}
